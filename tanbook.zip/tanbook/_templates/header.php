<!-- HEADER -->
 
<p>Navbar and all stuff</p>
<ul>
	<li><a href="<?=BASE_URL?>home">home</a></li>
	<li><a href="<?=BASE_URL?>profile">profile</a></li>
	<li><a href="<?=BASE_URL?>auth/log_out.php">logout</a></li>
</ul>