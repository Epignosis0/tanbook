<!-- FOOTER -->

<div align="center">
	<p>Copyright bla blah</p>
</div>